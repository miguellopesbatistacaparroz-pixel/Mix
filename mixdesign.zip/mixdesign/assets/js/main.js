/* =========================================================
   MixDesign — scripts
   ========================================================= */

/* ---- CONFIGURAÇÃO: preencha seus contatos reais aqui ----
   whatsapp: só números com DDD (ex.: '11999998888'). Se preenchido,
             o formulário envia a mensagem pelo WhatsApp.
   email:    usado pelo formulário quando não há WhatsApp.
   instagram: usuário sem @ (ex.: 'mixdesign').
   Contatos vazios não aparecem no site. */
const CONFIG = {
  whatsapp: '19989639238',
  email: '',
  instagram: 'mixdesignn_',
};

const PROJECTS = {
  aurora: {
    name: 'Aurora Arquitetura',
    category: 'Site institucional',
    type: 'Site institucional',
    desc: 'Um site institucional que traduz a linguagem de um escritório de arquitetura: tipografia editorial, muito respiro e um portfólio que conduz o visitante até o pedido de orçamento.',
    items: ['Home institucional', 'Portfólio de obras', 'Página do escritório', 'Formulário de orçamento', 'Layout responsivo'],
  },
  nordica: {
    name: 'Nórdica Café',
    category: 'Landing page',
    type: 'Landing page',
    desc: 'Landing page escura e sensorial para uma marca de cafés especiais. Uma página única, direta e pensada para levar o visitante à compra.',
    items: ['Página única', 'Seções de produto', 'Chamadas para compra', 'Integração com WhatsApp', 'Carregamento rápido'],
  },
  vertice: {
    name: 'Vértice Advocacia',
    category: 'Site para empresa',
    type: 'Site para empresa',
    desc: 'Site corporativo sóbrio para um escritório de advocacia, com áreas de atuação bem organizadas e agendamento de consulta em poucos cliques.',
    items: ['Áreas de atuação', 'Página da equipe', 'Agendamento de consulta', 'SEO básico', 'Layout responsivo'],
  },
  lina: {
    name: 'Lina Ribeiro Fotografia',
    category: 'Portfólio profissional',
    type: 'Portfólio profissional',
    desc: 'Portfólio editorial para fotógrafa, com galeria em mosaico que coloca as imagens em primeiro plano e uma navegação que não compete com o trabalho.',
    items: ['Galeria em mosaico', 'Páginas por ensaio', 'Sobre a fotógrafa', 'Contato direto', 'Imagens otimizadas'],
  },
};

const ICONS = {
  email: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>',
  whatsapp: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 11.5a8.5 8.5 0 0 1-12.6 7.4L3 20l1.2-4.2A8.5 8.5 0 1 1 20 11.5Z"/><path d="M9 8.5c0 3.5 3 6.5 6.5 6.5l1-1.6-2-1-1 .8a4 4 0 0 1-2.2-2.2l.8-1-1-2L9 8.5Z"/></svg>',
  instagram: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r=".6"/></svg>',
  arrow: '<svg class="cd-arrow" viewBox="0 0 20 20" aria-hidden="true"><path d="M6 14 14 6M7 6h7v7"/></svg>',
};

const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];
const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;

/* ---------- Títulos: divide em palavras para animar ---------- */
$$('[data-split]').forEach((heading) => {
  let i = 0;
  const walk = (node) => {
    [...node.childNodes].forEach((child) => {
      if (child.nodeType === Node.ELEMENT_NODE) return walk(child);
      if (child.nodeType !== Node.TEXT_NODE) return;
      const frag = document.createDocumentFragment();
      child.textContent.split(/(\s+)/).forEach((part) => {
        if (!part) return;
        if (/^\s+$/.test(part)) { frag.append(' '); return; }
        const w = document.createElement('span');
        w.className = 'w';
        w.style.setProperty('--i', i++);
        w.textContent = part;
        frag.append(w);
      });
      child.replaceWith(frag);
    });
  };
  walk(heading);
});

/* ---------- Botões: texto que rola no hover ---------- */
$$('.btn').forEach((btn) => {
  const textNode = [...btn.childNodes].find((n) => n.nodeType === Node.TEXT_NODE && n.textContent.trim());
  if (!textNode) return;
  const text = textNode.textContent.trim();
  const label = document.createElement('span');
  label.className = 'btn-label';
  label.dataset.text = text;
  const inner = document.createElement('span');
  inner.textContent = text;
  label.append(inner);
  textNode.replaceWith(label);
});

/* ---------- Header com blur no scroll + abertura com a logo ---------- */
const header = $('#header');
const intro = $('.intro');
const introInner = $('.intro-inner');
const introCue = $('.intro-cue');
let ticking = false;

function onScroll() {
  ticking = false;
  const y = window.scrollY;
  header.classList.toggle('is-scrolled', y > 8);
  const h = intro.offsetHeight;
  header.classList.toggle('past-intro', y > h * 0.6);
  const max = document.documentElement.scrollHeight - window.innerHeight;
  header.style.setProperty('--progress', max > 0 ? (y / max).toFixed(4) : 0);
  // a logo afasta e some suavemente conforme a pessoa rola
  const p = Math.min(Math.max(y / h, 0), 1);
  introInner.style.transform = `translate3d(0, ${p * 18}vh, 0) scale(${1 - p * 0.12})`;
  introInner.style.opacity = String(1 - p * 1.4);
  introCue.style.opacity = String(1 - p * 4);
}

onScroll();
window.addEventListener('scroll', () => {
  if (!ticking) { ticking = true; requestAnimationFrame(onScroll); }
}, { passive: true });
window.addEventListener('resize', onScroll);

/* ---------- Menu mobile ---------- */
const toggle = $('.menu-toggle');
const menu = $('#mobile-menu');

function openMenu() {
  menu.hidden = false;
  requestAnimationFrame(() => menu.classList.add('is-open'));
  toggle.setAttribute('aria-expanded', 'true');
  toggle.setAttribute('aria-label', 'Fechar menu');
  document.body.classList.add('menu-open');
  $('a', menu).focus();
}

function closeMenu({ focusToggle = true } = {}) {
  if (menu.hidden) return;
  menu.classList.remove('is-open');
  toggle.setAttribute('aria-expanded', 'false');
  toggle.setAttribute('aria-label', 'Abrir menu');
  document.body.classList.remove('menu-open');
  setTimeout(() => { menu.hidden = true; }, 300);
  if (focusToggle) toggle.focus();
}

toggle.addEventListener('click', () => (menu.hidden ? openMenu() : closeMenu()));
$$('a', menu).forEach((a) => a.addEventListener('click', () => closeMenu({ focusToggle: false })));

document.addEventListener('keydown', (e) => {
  if (menu.hidden) return;
  if (e.key === 'Escape') closeMenu();
  if (e.key === 'Tab') {
    const focusables = [toggle, ...$$('a', menu)];
    const first = focusables[0];
    const last = focusables[focusables.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  }
});

window.matchMedia('(min-width: 1024px)').addEventListener('change', (e) => {
  if (e.matches) closeMenu({ focusToggle: false });
});

/* ---------- Animações de entrada ---------- */
// Roda mesmo com "reduzir movimento": são só entradas suaves, sem loops.
const revealTargets = $$('[data-reveal], [data-steps]');

function reveal(el) {
  el.classList.add('is-visible');
  if (!el.hasAttribute('data-reveal')) return;
  // terminada a entrada, devolve as transições/hover próprios do elemento
  const delay = (parseFloat(getComputedStyle(el).getPropertyValue('--d')) || 0) * 130;
  setTimeout(() => el.removeAttribute('data-reveal'), 1700 + delay);
}

if ('IntersectionObserver' in window) {
  const io = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        reveal(entry.target);
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15, rootMargin: '0px 0px -60px 0px' });
  revealTargets.forEach((el) => io.observe(el));
} else {
  revealTargets.forEach(reveal);
}

/* ---------- Efeitos de mouse (só desktop) ---------- */
if (finePointer) {
  // Botões magnéticos: acompanham levemente o cursor
  $$('.btn-lg, .header-cta').forEach((btn) => {
    btn.addEventListener('pointermove', (e) => {
      const r = btn.getBoundingClientRect();
      const x = (e.clientX - r.left - r.width / 2) / (r.width / 2);
      const y = (e.clientY - r.top - r.height / 2) / (r.height / 2);
      btn.style.setProperty('--mx', `${(x * 6).toFixed(1)}px`);
      btn.style.setProperty('--my', `${(y * 4).toFixed(1)}px`);
    });
    btn.addEventListener('pointerleave', () => {
      btn.style.removeProperty('--mx');
      btn.style.removeProperty('--my');
    });
  });

  // Luz que segue o cursor
  $$('.feature, .project-media, .contact-direct a').forEach((el) => {
    el.addEventListener('pointermove', (e) => {
      const r = el.getBoundingClientRect();
      el.style.setProperty('--x', `${e.clientX - r.left}px`);
      el.style.setProperty('--y', `${e.clientY - r.top}px`);
    });
  });

  // Inclinação 3D da composição do hero
  const hero = $('.hero');
  const stage = $('.hv-stage');
  const wide = window.matchMedia('(min-width: 1024px)');
  hero.addEventListener('pointermove', (e) => {
    if (!wide.matches) return;
    const r = hero.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width - 0.5;
    const y = (e.clientY - r.top) / r.height - 0.5;
    stage.style.setProperty('--ry', `${(x * 8).toFixed(2)}deg`);
    stage.style.setProperty('--rx', `${(-y * 6).toFixed(2)}deg`);
  });
  hero.addEventListener('pointerleave', () => {
    stage.style.removeProperty('--rx');
    stage.style.removeProperty('--ry');
  });
}

/* ---------- Link ativo na navegação ---------- */
const navLinks = $$('.nav-link');
const sections = navLinks.map((l) => $(l.getAttribute('href'))).filter(Boolean);
if ('IntersectionObserver' in window) {
  const spy = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      const id = `#${entry.target.id}`;
      navLinks.forEach((l) => {
        const active = l.getAttribute('href') === id;
        l.classList.toggle('is-active', active);
        if (active) l.setAttribute('aria-current', 'true');
        else l.removeAttribute('aria-current');
      });
    });
  }, { rootMargin: '-45% 0px -50% 0px' });
  sections.forEach((s) => spy.observe(s));
}

/* ---------- Modal de projetos ---------- */
const modal = $('#project-modal');
const typeSelect = $('#f-tipo');

$$('[data-project]').forEach((btn) => {
  btn.addEventListener('click', () => {
    const p = PROJECTS[btn.dataset.project];
    if (!p) return;
    const browser = btn.closest('.project').querySelector('.browser');
    $('#modal-media').replaceChildren(browser.cloneNode(true));
    $('#modal-cat').textContent = p.category;
    $('#modal-title').textContent = p.name;
    $('#modal-desc').textContent = p.desc;
    $('#modal-list').replaceChildren(...p.items.map((t) => {
      const li = document.createElement('li');
      li.textContent = t;
      return li;
    }));
    modal.dataset.type = p.type;
    if (typeof modal.showModal === 'function') {
      modal.showModal();
      modal.scrollTop = 0;
    } else {
      document.querySelector('#contato').scrollIntoView();
    }
  });
});

$('.modal-close').addEventListener('click', () => modal.close());
modal.addEventListener('click', (e) => { if (e.target === modal) modal.close(); });
$('#modal-cta').addEventListener('click', (e) => {
  e.preventDefault();
  typeSelect.value = modal.dataset.type || '';
  modal.close();
  $('#contato').scrollIntoView({ behavior: 'smooth' });
  setTimeout(() => $('#f-nome').focus({ preventScroll: true }), 600);
});

/* ---------- Contatos diretos ---------- */
const direct = $('#contact-direct');
const contacts = [];
if (CONFIG.whatsapp) {
  const n = CONFIG.whatsapp.replace(/\D/g, '');
  contacts.push({ key: 'whatsapp', label: 'WhatsApp', value: formatPhone(n), href: `https://wa.me/55${n}` });
}
if (CONFIG.email) contacts.push({ key: 'email', label: 'E-mail', value: CONFIG.email, href: `mailto:${CONFIG.email}` });
if (CONFIG.instagram) contacts.push({ key: 'instagram', label: 'Instagram', value: `@${CONFIG.instagram}`, href: `https://instagram.com/${CONFIG.instagram}` });

contacts.forEach((c) => {
  const li = document.createElement('li');
  const external = c.href.startsWith('http');
  li.innerHTML = `<a href="${c.href}"${external ? ' target="_blank" rel="noopener"' : ''}>
    <span class="cd-icon">${ICONS[c.key]}</span>
    <span class="cd-text"><small>${c.label}</small><strong></strong></span>
    ${ICONS.arrow}
  </a>`;
  $('strong', li).textContent = c.value;
  direct.append(li);
});

/* ---------- Formulário ---------- */
function formatPhone(value) {
  const d = value.replace(/\D/g, '').slice(0, 11);
  if (d.length <= 2) return d.length ? `(${d}` : '';
  if (d.length <= 6) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
  if (d.length <= 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
}

const form = $('#contact-form');
const status = $('#form-status');
const whatsInput = $('#f-whats');

whatsInput.addEventListener('input', () => { whatsInput.value = formatPhone(whatsInput.value); });

const rules = {
  nome: (v) => (v.trim().length < 2 ? 'Informe seu nome.' : ''),
  email: (v) => (!v.trim() ? 'Informe seu e-mail.' : !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) ? 'Informe um e-mail válido.' : ''),
  whatsapp: (v) => { const d = v.replace(/\D/g, ''); return d && d.length < 10 ? 'Informe o número com DDD.' : ''; },
  tipo: (v) => (!v ? 'Selecione o tipo de projeto.' : ''),
  mensagem: (v) => (v.trim().length < 10 ? 'Conte um pouco mais sobre o projeto.' : ''),
};

function validateField(field) {
  const rule = rules[field.name];
  if (!rule) return true;
  const msg = rule(field.value);
  const errorEl = $(`#${field.getAttribute('aria-describedby')}`);
  field.setAttribute('aria-invalid', msg ? 'true' : 'false');
  if (errorEl) errorEl.textContent = msg;
  return !msg;
}

$$('input, select, textarea', form).forEach((field) => {
  field.addEventListener('blur', () => { if (field.value) validateField(field); });
  field.addEventListener('input', () => { if (field.getAttribute('aria-invalid') === 'true') validateField(field); });
});

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const fields = $$('input, select, textarea', form);
  const invalid = fields.filter((f) => !validateField(f));
  if (invalid.length) {
    invalid[0].focus();
    status.textContent = '';
    return;
  }

  const data = Object.fromEntries(new FormData(form));
  const lines = [
    'Olá, MixDesign! Gostaria de solicitar um orçamento.',
    '',
    `Nome: ${data.nome.trim()}`,
    data.empresa.trim() ? `Empresa: ${data.empresa.trim()}` : null,
    `E-mail: ${data.email.trim()}`,
    data.whatsapp ? `WhatsApp: ${data.whatsapp}` : null,
    `Tipo de projeto: ${data.tipo}`,
    '',
    data.mensagem.trim(),
  ].filter((l) => l !== null);
  const text = lines.join('\n');

  if (CONFIG.whatsapp) {
    const n = CONFIG.whatsapp.replace(/\D/g, '');
    window.open(`https://wa.me/55${n}?text=${encodeURIComponent(text)}`, '_blank', 'noopener');
    status.textContent = 'Pronto! Abrimos o WhatsApp com sua mensagem. É só tocar em enviar.';
  } else {
    const subject = `Orçamento — ${data.tipo} — ${data.nome.trim()}`;
    window.location.href = `mailto:${CONFIG.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(text)}`;
    status.textContent = `Pronto! Abrimos seu aplicativo de e-mail com a mensagem preenchida. Se nada abrir, escreva para ${CONFIG.email}.`;
  }
  form.reset();
  fields.forEach((f) => f.removeAttribute('aria-invalid'));
});
